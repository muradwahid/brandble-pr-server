import bcrypt from "bcrypt";
import httpStatus from "http-status";
import { Secret } from "jsonwebtoken";
import otpGenerator from 'otp-generator';
import config from "../../../config";
import ApiError from "../../../errors/ApiError";
import { FileUploadHelper } from "../../../helpers/FileUploadHelper";
import { jwtHelpers } from "../../../helpers/jwtHelpers";
import { sendResetOtpEmail } from "../../../helpers/mail";
import { IUploadFile } from "../../../interfaces/file";
import prisma from "../../../shared/prisma";
import { CustomRequest, ILoginUserResponse, IUser, IUserLogin } from "./auth.interface";
import { User } from "../../../generated/client/client";
// import { User } from "@prisma/client";

const allUsers = async () => {

  const result = await prisma.user.findMany();
    return result;
}

const userAllInfo = async (
  filters: { searchTerm?: string },
  options: { limit: number; page: number; sortBy?: string; sortOrder?: 'asc' | 'desc' }
) => {
  const { searchTerm } = filters;
  const { limit = 10, page = 1, sortBy = 'createdAt', sortOrder = 'desc' } = options;

  const skip = (page - 1) * limit;

  // Build search condition
  const whereConditions = searchTerm
    ? ({
      OR: [
        { name: { contains: searchTerm, mode: 'insensitive' as const } },
        { email: { contains: searchTerm, mode: 'insensitive' as const } },
        { company: { contains: searchTerm, mode: 'insensitive' as const } },
        { designation: { contains: searchTerm, mode: 'insensitive' as const } },
      ],
    })
    : {};

  // Fetch users with order counts
  const users = await prisma.user.findMany({
    where: whereConditions,
    select: {
      id: true,
      name: true,
      email: true,
      company: true,
      designation: true,
      image: true,
      role: true,
      createdAt: true,
      _count: {
        select: {
          orders: true,
        },
      },

      // Get actual orders to count by status
      orders: {
        select: {
          status: true,
        },
      },
    },
    orderBy: {
      [sortBy]: sortOrder,
    },
    skip,
    take: limit,
  });

  const total = await prisma.user.count({ where: whereConditions });

  const result = users.map((user: any) => {
    const allOrders = user.orders || [];
    const totalOrders = user._count.orders;

    const runningOrders = allOrders.filter((order: any) =>
      ['pending', 'in_progress', 'under_review', 'assigned'].includes(order.status)
    ).length;

    const publishedOrders = allOrders.filter((order:any) =>
      ['completed', 'published', 'live', 'delivered'].includes(order.status)
    ).length;

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      company: user.company,
      designation: user.designation,
      image: user.image,
      role: user.role,
      createdAt: user.createdAt,

      totalOrders,
      runningOrders,
      publishedOrders,
    };
  });

  return {
    data: result,
    meta: {
      page,
      limit,
      total,
      totalPage: Math.ceil(total / limit),
    },
  };
};

const createUser = async (user: IUser) => {
  // Check if user already exists by email
  const existingUser = await prisma.user.findFirst({
    where: { email: user.email }
  });
  if (existingUser) {
    throw new ApiError(httpStatus.CONFLICT, 'User already exists');
  }
  // Hash password before saving
  const hashedPassword = await bcrypt.hash(user.password, 10);
  // Create user with hashed password
    const result = await prisma.user.create({
        data: {
            ...user,
            password: hashedPassword
        }
    });
    return result;
}

const loginUser = async (user: IUserLogin): Promise<ILoginUserResponse> => {
  // Find user by email
    const result = await prisma.user.findFirst({
        where: {
            email: user.email,
        },
        select:{
            id:true,
            name:true,
          email: true,
          password: true,
          role: true,
        }
    });
  // Check if user exists
    if(!result){
        throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
    }
  // Check if password is correct
  const isPasswordCorrect = await bcrypt.compare(user.password as string, result.password as string);
  if(!isPasswordCorrect){
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Invalid password');
  }

  //create access token & refresh token
  const accessToken = jwtHelpers.createToken(
    { id: result?.id, role: result?.role },
    config.jwt.secret as Secret,
    config.jwt.expires_in as string
  )
  const refreshToken = jwtHelpers.createToken(
    { id: result?.id, role: result?.role },
    config.jwt.refresh_secret as Secret,
    config.jwt.refresh_expires_in as string
  )

  return {
    accessToken,
    refreshToken,
  };
}

const getUserByCookie = async (token: string) => {
  const verifiedToken = jwtHelpers.verifyToken(token, config.jwt.secret as Secret);
  const { id } = verifiedToken;
  const result = await prisma.user.findUnique({
    where:{
      id
    },
    include:{
      orders:true
    }
  });
  return result;
}



const getSingleUser = async (id: string) => {

    const result = await prisma.user.findUnique({
        where:{
            id
        },
        include:{
          orders:true
        }
    });
    return result;
}

const sendEmailOTP = async (email: string) => { 
  const user = await prisma.user.findFirst({
    where:{
      email
    }
  });

  if (!user) throw new ApiError(httpStatus.NOT_FOUND, 'User not found!');

  const otp = otpGenerator.generate(6, {
    upperCaseAlphabets: false,
    specialChars: false,
    lowerCaseAlphabets: false,
  });
  const expiresIn = new Date(Date.now() + 30 * 60 * 1000);
  const updateUser = await prisma.user.update({
    where: { email },
    data: {
      otp,
      otpExpires: expiresIn,
    }
  });

  if (!updateUser) throw new ApiError(httpStatus.NOT_MODIFIED, 'Something went wrong!');

  const emailSent = await sendResetOtpEmail(email, otp);

  return {
    success: true,
    emailSent
  };
}

const verifyOTP = async (email: string, otp: string) => {
  
  const user = await prisma.user.findUnique({
    where: { email },
    select: {
      id: true,
      otp: true,
      otpExpires: true,
    }
  });

  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  if (user.otp !== otp) {
    throw new ApiError(401, 'OTP didn’t matched!');
  }

  if (user.otpExpires &&  new Date() > user.otpExpires) {
    await prisma.user.update({
      where: { id: user.id },
      data: { otp: null, otpExpires: null },
    });

    throw new ApiError(410, 'OTP has expired');
  }

  return user;
};

const resetPassword = async (password: string, id: string): Promise<User> => { 

  const user = await prisma.user.findUnique({
    where: { id },
    select: {
      id: true,
      otp: true,
      otpExpires: true,
    }
  });

  if (!user) {
    throw new ApiError(404, 'User not found!');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const updateUser = await prisma.user.update({
    where: { id },
    data: {
      password: hashedPassword,
      otp: null,
      otpExpires: null,
    }
  });

  return updateUser;
}
const forgotPassword = async (newPassword: string, email: string): Promise<User> => {

  const user = await prisma.user.findUnique({
    where: { email },
    select: {
      id: true,
      otp: true,
      otpExpires: true,
    }
  });

  if (!user) {
    throw new ApiError(404, 'User not found!');
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);
  const updateUser = await prisma.user.update({
    where: { email },
    data: {
      password: hashedPassword,
      otp: null,
      otpExpires: null,
    }
  });

  return updateUser;
}

const updateUser = async (
  id: string,
  req: CustomRequest,
) => {


    const file = req.file as IUploadFile;
    const data = { ...req.body };
    if (file) {
      const cloudflare = await FileUploadHelper.uploadToR2(file);
      // const uploadedProfileImage = await FileUploadHelper.uploadToCloudinary(file);
      // if (uploadedProfileImage && uploadedProfileImage.secure_url) {
      //   data.image = uploadedProfileImage.secure_url;
      // }
      if (cloudflare && cloudflare.url) {
        data.image = cloudflare.url;
      }
      
    }


  try {
    const result = await prisma.user.update({
      where: {
        id,
      },
      data,
    });
    return result;
  } catch (error) {
    throw error;
  }
};

const deleteUser = async (id: string) => {

    const result = await prisma.user.delete({
        where:{
            id
        }
    });
    return result;
}

const getAdminRole = async () => {
  const result = await prisma.user.findFirst({
    where:{
      role:'admin'
    }
  });
  return result;
}


export const AuthService = {
    allUsers,
    createUser,
    loginUser,
  verifyOTP,
  resetPassword,
  forgotPassword,
    getSingleUser,
      sendEmailOTP,
      updateUser,
  deleteUser,
  getUserByCookie,
  getAdminRole,
  userAllInfo
}