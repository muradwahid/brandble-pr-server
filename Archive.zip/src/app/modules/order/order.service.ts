
import { subDays, format, startOfDay, endOfDay, startOfMonth, endOfMonth, subMonths, startOfYear, endOfYear, subWeeks, startOfWeek } from 'date-fns';
import httpStatus from 'http-status';
import ApiError from '../../../errors/ApiError';
import { paginationHelpers } from '../../../helpers/paginationHelper';
import { IPaginationOptions } from '../../../interfaces/pagination';
import prisma from '../../../shared/prisma';
import { NotificationService } from '../notification/notification.service';
import { publicationSearchableFields } from '../publication/publication.constant';
import { dayNames, directSortableFields, nestedSortableFields, singleUserOrderSearchableFields } from './order.constant';
import { IOrder, IOrderSearchableFields } from './order.interface';
import { eachDayOfInterval, eachHourOfInterval, eachMonthOfInterval } from './order.functions';
import { Prisma } from '../../../generated/client/client';
import { logger } from '../../../shared/logger';
import Stripe from 'stripe';
import config from '../../../config';
import { SocketHelper } from '../../../helpers/SocketHelper';

const stripe = new Stripe(config.stripe.secretKey as string);

const userAllOrders = async (
  filters: IOrderSearchableFields,
  options: IPaginationOptions,
  userId: string
) => {

  const { page, limit, skip } = paginationHelpers.calculatePagination(options);
  const { searchTerm, ...filterData } = filters;

  const andConditions = new Array();

  if (searchTerm) {
    andConditions.push({
      OR: [
        // Search in direct Order fields
        {
          orderId: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          orderType: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          status: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          detailsSubmitted: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        // Search in related Publication fields
        {
          publication: {
              OR: [
                {
                  title: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  region: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  location: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  da: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  dr: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                }
              ]
          }
        },
        // Search in User fields
        {
          user: {
            OR: [
              {
                name: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              },
              {
                email: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              }
            ]
          }
        }
      ]
    })
  }


  const filterKeys = Object.keys(filterData);

  if (filterKeys.length > 0) {
    andConditions.push({
      AND: filterKeys.map(key => {
        if (key === 'status') {
          return {
            status: {
              equals: (filterData as any)[key]
            }
          }
        }
        if (key === 'publication') {
          return {
            publication: {
              id: (filterData as any)[key]
            }
          }
        }
        if (key === 'wonArticle') {
          return {
            wonArticle: {
              id: (filterData as any)[key]
            }
          }
        }
        if (key === 'writeArticle') {
          return {
            writeArticle: {
              id: (filterData as any)[key]
            }
          }
        }
        return {
          [key]: {
            equals: (filterData as any)[key]
          }
        }
      })
    })
  }
  const whereConditions = andConditions.length > 0 ? { AND: andConditions, userId } : { userId};

  const result = await prisma.order.findMany({
    where: whereConditions,
    skip,
    take: limit,
    orderBy:
      options.sortBy && options.sortOrder
        ? {
          [options.sortBy as any]: options.sortOrder,
        }
        : {
          createdAt: 'desc',
        },
    include: {
      user: true,
      wonArticle: true,
      writeArticle: true,
      paymentMethod:true,
      publication:true
    },
  });

  const total = await prisma.order.count({ where: whereConditions });
  const totalOrders = await prisma.order.count({ where: { userId } })


  return {
    meta: {
      page,
      limit,
      total,
      totalOrders,
      totalPage: Math.ceil(total / limit),
    },
    data: result,
  };
};

const userPublishedOrders = async (
  filters: IOrderSearchableFields,
  options: IPaginationOptions,
  userId: string
) => { 
  // const { searchTerm, ...filterData } = filters;

  const { page, limit, skip } = paginationHelpers.calculatePagination(options);
  const whereConditions: Prisma.OrderWhereInput = {
    userId,
    status: 'published',
  };

  const result = await prisma.order.findMany({
    where: whereConditions,
    skip,
    take: limit,
    orderBy:
      options.sortBy && options.sortOrder
        ? {
          [options.sortBy as any]: options.sortOrder,
        }
        : {
          createdAt: 'desc',
        },
    include: {
      user: true,
      wonArticle: true,
      writeArticle: true,
      publication:true
    }
  });

  const total = await prisma.order.count({ where: whereConditions });
  return {
    meta: {
      page,
      limit,
      total,
    },
    data: result,
  };

};


const getAdminAllOrders = async (
  filters: IOrderSearchableFields,
  options: IPaginationOptions
) => {

  const { page, limit, skip , sortBy,sortOrder} = paginationHelpers.calculatePagination(options);
  const { searchTerm, ...filterData } = filters;

  const andConditions = new Array();

  if (searchTerm) {
    andConditions.push({
      OR: [
        // Search in direct Order fields
        {
          orderId: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          orderType: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          status: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          detailsSubmitted: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        // Search in related Publication fields
        {
          publication: {
              OR: [
                {
                  title: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  region: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  location: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  da: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  dr: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                }
              ]
          }
        },
        // Search in User fields
        {
          user: {
            OR: [
              {
                name: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              },
              {
                email: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              }
            ]
          }
        }
      ]
    })
  }


  const filterKeys = Object.keys(filterData);

  if (filterKeys.length > 0) {
    andConditions.push({
      AND: filterKeys.map(key => {
        if (key === 'status') {
          return {
            status: {
              equals: (filterData as any)[key]
            }
          }
        }
        if (key === 'publication') {
          return {
            publication: {
              id: (filterData as any)[key]
            }
          }
        }
        if (key === 'wonArticle') {
          return {
            wonArticle: {
              id: (filterData as any)[key]
            }
          }
        }
        if (key === 'writeArticle') {
          return {
            writeArticle: {
              id: (filterData as any)[key]
            }
          }
        }
        return {
          [key]: {
            equals: (filterData as any)[key]
          }
        }
      })
    })
  }


  let orderSortBy: any = { createdAt: 'desc' };

  if (sortBy && sortOrder) {
    if (directSortableFields.includes(sortBy)) {
      orderSortBy = [
        { [sortBy]: sortOrder },
        { createdAt: 'desc' },
      ];
    } else if (nestedSortableFields.includes(sortBy)) {
      orderSortBy = [
        { publication: { [sortBy]: sortOrder } },
        { publication: { id: 'asc' } },
        { createdAt: 'desc' },
      ];
    } else {
      orderSortBy = { createdAt: 'desc' };
    }
  }


  const whereConditions = andConditions.length > 0 ? { AND: andConditions } : {};

  const result = await prisma.order.findMany({
    where: whereConditions,
    skip,
    take: limit,
    orderBy: orderSortBy,
    include: {
      user: true,
      wonArticle: true,
      writeArticle: true,
      paymentMethod:true,
      publication:true
    },
  });

  const total = await prisma.order.count();

  return {
    meta: {
      page,
      limit,
      total,
    },
    data: result,
  };
};


export const getAdminOrders = async (filters: any, options: IPaginationOptions) => {
  const { page, limit, skip, sortBy, sortOrder } =
    paginationHelpers.calculatePagination(options);

  const andConditions: Prisma.OrderWhereInput[] = [];

  // status
  if (filters?.status) {
    andConditions.push({ status: { equals: filters.status as any } });
  }

  // orderType
  if (filters?.orderType) {
    andConditions.push({ orderType: { equals: filters.orderType as any } });
  }

  // title -> publication.title
  if (filters?.title) {
    const t = String(filters.title).trim();
    if (t.length) {
      andConditions.push({
        publication: { title: { contains: t, mode: "insensitive" } },
      });
    }
  }

  //createdAt default = today, but if filters.date exists then use that day
  {
    const baseDate = filters.date ? new Date(filters.date) : new Date();

    // start of day (server local time)
    const start = new Date(baseDate);
    start.setHours(0, 0, 0, 0);

    // end of day (server local time)
    const end = new Date(baseDate);
    end.setHours(23, 59, 59, 999);

    andConditions.push({
      createdAt: { gte: start, lte: end },
    });
  }

  const whereConditions: Prisma.OrderWhereInput =
    andConditions.length > 0 ? { AND: andConditions } : {};

  let orderBy: Prisma.OrderOrderByWithRelationInput[] = [{ createdAt: "desc" }];

  if (sortBy && sortOrder) {
    if (sortBy === "title") {
      orderBy = [
        { publication: { title: sortOrder as Prisma.SortOrder } },
        { createdAt: "desc" },
      ];
    } else {
      orderBy = [
        { [sortBy]: sortOrder as Prisma.SortOrder } as Prisma.OrderOrderByWithRelationInput,
        { createdAt: "desc" },
      ];
    }
  }

  const [data, total] = await Promise.all([
    prisma.order.findMany({
      where: whereConditions,
      skip,
      take: limit,
      orderBy,
      include: {
        user: true,
        wonArticle: true,
        writeArticle: true,
        paymentMethod: true,
        publication: true,
      },
    }),
    prisma.order.count({ where: whereConditions }),
  ]);

  return {
    meta: { page, limit, total },
    data,
  };
};

const userOrders = async (
  filters: IOrderSearchableFields,
  options: IPaginationOptions,
  userId: string
) => {

  const { page, limit, skip } = paginationHelpers.calculatePagination(options);
  const { searchTerm, ...filterData } = filters;

  const andConditions = new Array();

  if (searchTerm) {
    andConditions.push({
      OR: [
        // Search in direct Order fields
        {
          id: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          orderId: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          orderType: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          status: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          detailsSubmitted: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        // Search in related Publication fields
        {
          publication: {
              OR: [
                {
                  title: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  region: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  location: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  da: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                },
                {
                  dr: {
                    contains: searchTerm,
                    mode: 'insensitive'
                  }
                }
              ]
          }
        },
        // Search in User fields
        {
          user: {
            OR: [
              {
                name: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              },
              {
                email: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              }
            ]
          }
        }
      ]
    })
  }


  const filterKeys = Object.keys(filterData);

  if (filterKeys.length > 0) {
    andConditions.push({
      AND: filterKeys.map(key => {
        if (key === 'status') {
          return {
            status: {
              equals: (filterData as any)[key]
            }
          }
        }
        if (key === 'publication') {
          return {
            publication: {
              id: (filterData as any)[key]
            }
          }
        }
        if (key === 'wonArticle') {
          return {
            wonArticle: {
              id: (filterData as any)[key]
            }
          }
        }
        if (key === 'writeArticle') {
          return {
            writeArticle: {
              id: (filterData as any)[key]
            }
          }
        }
        return {
          [key]: {
            equals: (filterData as any)[key]
          }
        }
      })
    })
  }
  const whereConditions = andConditions.length > 0 ? { AND: andConditions, userId } : {userId};

  const result = await prisma.order.findMany({
    where: whereConditions,
    skip,
    take: limit,
    orderBy:
      options.sortBy && options.sortOrder
        ? {
          [options.sortBy as any]: options.sortOrder,
        }
        : {
          createdAt: 'desc',
        },
    include: {
      user: true,
      wonArticle: true,
      writeArticle: true,
      paymentMethod:true,
      publication:true
    },
  });

  const total = await prisma.order.count({ where: whereConditions });

  return {
    meta: {
      page,
      limit,
      total,
    },
    data: result,
  };
};

const createOrder = async (order: any) => {
  const { userId, publicationIds, paymentMethodId, currency = 'usd' } = order;

  const pubIds = publicationIds.split(',').map((id: string) => id.trim());
  const currentUser = await prisma.user.findUnique({ where: { id: userId } });

  if (!currentUser?.stripeCustomerId) throw new ApiError(400, 'Stripe customer not found');

  const publications = await prisma.publication.findMany({
    where: { id: { in: pubIds } },
    select: { id: true, price: true,title:true },
  });

  const paymentMethod = await prisma.paymentMethod.findFirst({
    where: {
      stripePaymentMethodId: paymentMethodId
    }
  })

  if (!paymentMethod) throw new ApiError(400, 'Payment method not found');



  const results = [];

  for (const publication of publications) {
    const pubId = publication.id as string;

    try {
      if (!publication) {
        results.push({ pubId, status: 'failed', error: 'Publication not found!' });
        continue;
      }

      const amount = Math.round((publication.price || 0) * 100);

      const paymentIntent = await stripe.paymentIntents.create({
        amount,
        currency,
        customer: currentUser.stripeCustomerId,
        payment_method: paymentMethodId,
        off_session: true,
        confirm: true,
      });

      if (paymentIntent.status === 'succeeded') {
        const newOrder = await prisma.order.create({
          data: {
            userId,
            publicationId: pubId,
            amount: publication.price || 0,
            paymentStatus: 'paid', 
            status: 'pending',
            paymentMethodId: paymentMethod.id
          },
        });
        if (newOrder.id) { 
          await NotificationService.createNotification(
                currentUser.id,
                'Order Confirmed',
                `Your order <span class='font-semibold'>#${newOrder.orderId}</span> has been successfully placed. Kindly submit the required information to processing and stay on schedule.`,
                'order_status',
                newOrder.id,
                currentUser.id,
                'client',
                'placed'
              );
        }
        results.push({id:newOrder.id, publication, orderId: newOrder.orderId, status: 'success', amount: publication.price || 0 });
      } else {
        results.push({ publication, status: 'failed', error: 'Payment failed!' });
      }
    } catch (error: any) {
      results.push({ pubId, status: 'failed', error: error.message });
    }
  }
  const successfulOrders = results.filter(result => result.status === 'success');

  if (results.length > 0 && successfulOrders.length > 0) {
    const totalAmount = successfulOrders.reduce((sum, order) => sum + (order.amount || 0), 0);
    const convertedAmount = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalAmount);
    await NotificationService.createNotification(
      currentUser.id,
      'New Order Received',
      `<span class='font-semibold'>#${currentUser.name}</span> placed ${successfulOrders.length || 1} Order including <b>Publish Article</b> & <span class='font-semibold'>Write and Publish Article</span>. Waiting for information submission. Total: ${convertedAmount}`,
      'order_status',
      successfulOrders[0].id,
      currentUser.id,
      'admin',
      'placed'
    );
  }

  return {
    message: "Order processing completed",
    summary: results
  };
};

const runningOrders = async (filters: IOrderSearchableFields, options: IPaginationOptions, id: string) => {
  
  const { page, limit, skip } = paginationHelpers.calculatePagination(options);
  const { searchTerm } = filters;

  const andConditions = new Array();

  const isUUID = typeof searchTerm === 'string' && searchTerm?.length === 36;

  if (searchTerm) {
    andConditions.push({
      OR: [
        ...(isUUID ? [{ id: { equals: searchTerm } }] : []),
        {
          orderId: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          orderType: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        {
          detailsSubmitted: {
            contains: searchTerm,
            mode: 'insensitive'
          }
        },
        // Search in related Publication fields
        {
          publication: {
            OR: [
              {
                title: {
                  contains: searchTerm,
                  mode: 'insensitive'
                }
              }
            ]
          }
        }
      ]
    })
  }
  const fixedConditions = {
    userId: id,
    status: {
      in: ['processing', 'pending']
    }
  };
  const whereConditions = { AND: [...andConditions, fixedConditions] };

  const result = await prisma.order.findMany({
    where: whereConditions,
    skip,
    take: limit,
    orderBy: {
      createdAt: 'desc'
    },
    include: {
      user: true,
      publication: true,
      wonArticle: true,
      writeArticle: true,
    }
  })

  const total = await prisma.order.count({where:whereConditions})
  const totalOrders = await prisma.order.count({ where: { AND: [fixedConditions]} })


  return  {
    meta: {
      page,
      limit,
      total,
      totalOrders,
      totalPage: Math.ceil(total / limit),
    },
    data: result,
  };
}

const getOrderById = async (id: string) => {
  const result = await prisma.order.findUnique({
    where: {
      id,
    },
    include: {
      user: true,
      wonArticle: true,
      writeArticle: true,
      paymentMethod: true,
      publication:true
    },
  });

  return result;
};

const getSpecificUserOrders = async (
  userId: string,
  filters: IOrderSearchableFields,
  options: IPaginationOptions
) => {
  const { searchTerm, ...filterData } = filters;
  const { page, limit, skip } = paginationHelpers.calculatePagination(options);

  const andConditions = [];

  andConditions.push({ userId });

  if (searchTerm) {
    andConditions.push({
      OR: [
        ...singleUserOrderSearchableFields.map((field) => ({
          [field]: { contains: searchTerm, mode: 'insensitive' },
        })),
        {
          publication: {
            OR: publicationSearchableFields.map((field) => ({
              [field]: { contains: searchTerm, mode: 'insensitive' },
            })),
          },
        },
      ],
    });
  }

  if (Object.keys(filterData).length > 0) {
    andConditions.push({
      AND: Object.entries(filterData).map(([key, value]) => ({
        [key]: { equals: value },
      })),
    });
  }

  const whereConditions =
    andConditions.length > 0 ? { AND: andConditions } : {};

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where: whereConditions,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        publication: {
          select: {
            id: true,
            title: true,
            logo: true,
            price: true,
            genre: true,
            location: true,
            sponsor: true,
            doFollow: true,
            da: true,
            dr: true,
            index: true,
          },
        },
      },
    }),
    prisma.order.count({ where: whereConditions }),
  ]);

  return {
    meta: {
      page,
      limit,
      total,
      totalPage: Math.ceil(total / limit),
    },
    data: orders,
  };
};

const updateOrder = async (id: string, data: Partial<IOrder | any>): Promise<Partial<IOrder> | null> => {
  const result = await prisma.order.update({
    where: {
      id,
    },
    data,
    include: {
      user: true,
      publication: true,
      wonArticle: true,
      writeArticle: true,
    },
  });
  return result as unknown as Partial<IOrder>;
};

const deleteOrder = async (id: string): Promise<Partial<IOrder> | null> => {
  const result = await prisma.order.delete({
    where: {
      id,
    },
  });
  return result as unknown as Partial<IOrder>;
};
const getOrderStatistics = async (filters: { today?: string; thisWeek?: string }) => {
  const now = new Date();

  // Determine date ranges based on filters
  let currentPeriodRange: { gte: Date };
  let previousPeriodRange: { gte: Date; lt: Date };
  let periodLabel: string;
  let previousPeriodLabel: string;

  if (filters.today) {
    // Today vs Yesterday
    const todayStart = startOfDay(now);
    const yesterdayStart = startOfDay(subDays(now, 1));

    currentPeriodRange = { gte: todayStart };
    previousPeriodRange = { gte: yesterdayStart, lt: todayStart };
    periodLabel = 'Today';
    previousPeriodLabel = 'Yesterday';

  } else if (filters.thisWeek) {
    // This Week vs Last Week
    const thisWeekStart = startOfWeek(now, { weekStartsOn: 1 });
    const lastWeekStart = startOfWeek(subWeeks(now, 1), { weekStartsOn: 1 });

    currentPeriodRange = { gte: thisWeekStart };
    previousPeriodRange = { gte: lastWeekStart, lt: thisWeekStart };
    periodLabel = 'This Week';
    previousPeriodLabel = 'Last Week';

  } else {
    // This Month vs Last Month (default)
    const thisMonth = startOfMonth(now);
    const lastMonth = startOfMonth(subMonths(now, 1));

    currentPeriodRange = { gte: thisMonth };
    previousPeriodRange = { gte: lastMonth, lt: thisMonth };
    periodLabel = 'This Month';
    previousPeriodLabel = 'Last Month';
  }

  // Run queries for both periods in parallel
  const [currentPeriodData, previousPeriodData] = await Promise.all([
    // Current period data
    getOrderStatsForPeriod(currentPeriodRange),
    // Previous period data
    getOrderStatsForPeriod(previousPeriodRange)
  ]);

  // Calculate growth rates
  const growthRates = {
    totalOrders: calculateGrowthRate(currentPeriodData.totalOrders, previousPeriodData.totalOrders),
    newClients: calculateGrowthRate(currentPeriodData.newClients, previousPeriodData.newClients),
    repeatClients: calculateGrowthRate(currentPeriodData.repeatClients, previousPeriodData.repeatClients),
    delivered: calculateGrowthRate(currentPeriodData.delivered, previousPeriodData.delivered),
    inProgress: calculateGrowthRate(currentPeriodData.inProgress, previousPeriodData.inProgress),
  };

  return {
    summary: {
      period: periodLabel,
      previousPeriod: previousPeriodLabel,
      filter: filters.today ? 'today' : filters.thisWeek ? 'thisWeek' : 'thisMonth'
    },
    currentPeriod: currentPeriodData,
    previousPeriod: previousPeriodData,
    growthRates,
  };
};

// Helper function to get order statistics for a specific period
const getOrderStatsForPeriod = async (dateRange: { gte: Date; lt?: Date }) => {
  // 1. Get how many orders each user has made in this period
  const userOrderCounts = await prisma.order.groupBy({
    by: ['userId'],
    where: {
      createdAt: dateRange
    },
    _count: {
      _all: true,
    },
  });

  // 2. Classify users for this period
  let newClients = 0;
  let repeatClients = 0;

  for (const user of userOrderCounts) {
    if (user._count._all === 1) {
      newClients++;
    } else if (user._count._all > 1) {
      repeatClients++;
    }
  }

  // 3. Get status counts for this period
  const statusCounts = await prisma.order.groupBy({
    by: ['status'],
    where: {
      createdAt: dateRange
    },
    _count: {
      _all: true,
    },
  });

  const totalOrders = userOrderCounts.reduce((sum, u) => sum + u._count._all, 0);

  const delivered = statusCounts.find(s => s.status === 'published')?._count._all || 0;
  const inProgress =
    (statusCounts.find(s => s.status === 'pending')?._count._all || 0) +
    (statusCounts.find(s => s.status === 'processing')?._count._all || 0);

  return {
    totalOrders,
    newClients,
    repeatClients,
    delivered,
    inProgress,
  };
};

// Helper function to calculate growth rate
const calculateGrowthRate = (current: number, previous: number): string => {
  if (previous === 0) {
    return current > 0 ? '+100%' : '0%';
  }

  const rate = ((current - previous) / previous) * 100;
  const formatted = Math.abs(rate) < 0.1 ? '0%' : rate.toFixed(1) + '%';

  return rate > 0 ? `+${formatted}` : formatted;
};

const getRevenueStatistics = async () => {
  const today = new Date();
  const sevenDaysAgo = subDays(today, 6); 

  const orders = await prisma.order.findMany({
    where: {
      createdAt: {
        gte: sevenDaysAgo,
        lte: today,
      },
    },
    select: {
      amount: true,
      createdAt: true,
    },
  });

  let todayRevenue = 0;
  let last7DaysRevenue = 0;

  const weeklyRevenue = Array(7).fill(0);

  orders.forEach((order) => {
    const orderDate = order.createdAt;
    const daysAgo = Math.floor((today.getTime() - orderDate.getTime()) / 86400000);

    if (daysAgo >= 0 && daysAgo < 7) {
      last7DaysRevenue += order.amount;

      if (daysAgo === 0) {
        todayRevenue += order.amount;
      }

      const jsDay = orderDate.getDay();
      const ourIndex = jsDay === 0 ? 1 : jsDay === 6 ? 0 : jsDay;
      weeklyRevenue[ourIndex] += order.amount;
    }
  });

  const chartData = dayNames.map((day, index) => ({
    name: day,
    uv: Math.round(weeklyRevenue[index]),
    amt: weeklyRevenue[index] + 500,
  }));

  return {
    todayRevenue,
    weekRevenue:last7DaysRevenue,  
    week:chartData,       
  };
};

const getPaymentRevenueStatistics = async () => {
  const now = new Date();

  const allRevenue = await prisma.order.groupBy({
    by: ['createdAt'],
    where: {
      createdAt: { gte: startOfYear(now) },
    },
    _sum: { amount: true },
    orderBy: { createdAt: 'asc' },
  });

  const revenueByDay = new Map<string, number>();
  const revenueByMonth = new Map<string, number>();
  const revenueByHour = new Map<string, number>();

  allRevenue.forEach(item => {
    const date = new Date(item.createdAt);
    const dayKey = format(date, 'yyyy-MM-dd');
    const monthKey = format(date, 'yyyy-MM');
    const hourKey = format(date, 'yyyy-MM-dd HH');

    const amount = item._sum.amount || 0;

    revenueByDay.set(dayKey, (revenueByDay.get(dayKey) || 0) + amount);
    revenueByMonth.set(monthKey, (revenueByMonth.get(monthKey) || 0) + amount);
    revenueByHour.set(hourKey, (revenueByHour.get(hourKey) || 0) + amount);
  });

  const getRev = (date: Date, type: 'day' | 'month' | 'hour') => {
    if (type === 'day') return revenueByDay.get(format(date, 'yyyy-MM-dd')) || 0;
    if (type === 'month') return revenueByMonth.get(format(date, 'yyyy-MM')) || 0;
    if (type === 'hour') return revenueByHour.get(format(date, 'yyyy-MM-dd HH')) || 0;
    return 0;
  };

  const totalToday = eachHourOfInterval(startOfDay(now), endOfDay(now))
    .reduce((sum, hour) => sum + getRev(hour, 'hour'), 0);

  const totalLast7Days = eachDayOfInterval(subDays(now, 6), now)
    .reduce((sum, day) => sum + getRev(day, 'day'), 0);

  const totalThisMonth = eachDayOfInterval(startOfMonth(now), endOfMonth(now))
    .reduce((sum, day) => sum + getRev(day, 'day'), 0);

  const totalLastMonth = (() => {
    const last = subMonths(now, 1);
    return eachDayOfInterval(startOfMonth(last), endOfMonth(last))
      .reduce((sum, day) => sum + getRev(day, 'day'), 0);
  })();

  const totalThisYear = eachMonthOfInterval(startOfYear(now), endOfYear(now))
    .reduce((sum, month) => sum + getRev(month, 'month'), 0);

  return {
    today: eachHourOfInterval(startOfDay(now), endOfDay(now)).map(hour => ({
      name: format(hour, 'ha'),
      uv: getRev(hour, 'hour'),
      pv: getRev(hour, 'hour'),
      amt: getRev(hour, 'hour'),
    })),

    last7Days: eachDayOfInterval(subDays(now, 6), now).map(day => ({
      name: format(day, 'EEE'),
      uv: getRev(day, 'day'),
      pv: getRev(day, 'day'),
      amt: getRev(day, 'day'),
    })),

    thisMonth: eachDayOfInterval(startOfMonth(now), endOfMonth(now)).map(day => ({
      name: format(day, 'dd EEE'),
      uv: getRev(day, 'day'),
      pv: getRev(day, 'day'),
      amt: getRev(day, 'day'),
    })),

    lastMonth: (() => {
      const last = subMonths(now, 1);
      return eachDayOfInterval(startOfMonth(last), endOfMonth(last)).map(day => ({
        name: format(day, 'dd EEE'),
        uv: getRev(day, 'day'),
        pv: getRev(day, 'day'),
        amt: getRev(day, 'day'),
      }));
    })(),

    thisYear: eachMonthOfInterval(startOfYear(now), endOfYear(now)).map(month => ({
      name: format(month, 'MMM'),
      uv: getRev(month, 'month'),
      pv: getRev(month, 'month'),
      amt: getRev(month, 'month'),
    })),

    revenue: {
      today: totalToday,
      last7Days: totalLast7Days,
      thisMonth: totalThisMonth,
      lastMonth: totalLastMonth,
      thisYear: totalThisYear,
    },
  };
};

const getUpcomingDeadlines = async () => {

  const result = await prisma.order.findMany({
    where: {
      status: {
        notIn: ['completed', 'unable-to-published'],
      },
    },
    include: {
      publication: true,
      wonArticle: true,
      writeArticle:true
    }
  });
  const total = await prisma.order.count();

  // Format for frontend
  return {
    total,
    orders: result
  }
};

const updateOrderStatus = async (orderId: string, status: string, adminUserId?: string) => {

  return await prisma.$transaction(async (tx) => {
    const currentOrder = await tx.order.findUnique({
      where: { id: orderId },
      include: { user: true, publication: true },
    });

    if (!currentOrder) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Order not found');
    }

    const updatedOrder = await tx.order.update({
      where: { id: orderId },
      data: { status },
      include: {
        user: true,
        publication: true,
      },
    });

    // Notification message
    let notificationTitle, notificationMessage,submitStatus;
    
    // const orderStatus = ['published', 'submitted', 'processing','unabletopublish']
    switch (status) {
      case 'published':
        notificationTitle = 'Article Published Successfully';
        notificationMessage = `Great news! Your article <span class='font-semibold'>"${updatedOrder.orderType === 'wonArticle' ? 'Write Article' : 'Write and Publish Article'}"</span> has been published on <span class='font-semibold'>${updatedOrder.publication?.title || 'the site'}</span>`;
        submitStatus = status;
        break;
      case 'processing':
        notificationTitle = 'Order Processing';
        notificationMessage = `Thanks for submitting information. Your order <span class='font-semibold'>#${updatedOrder.orderId}</span> is in processing. Soon we'll update you final status.`;
        submitStatus = status;
        break;
      case 'unabletopublish':
        notificationTitle = 'Unable to Publish Article';
        notificationMessage = `We're unable to publish article due to some unwanted issues. We're working on it, and we'll update you again. Message us for further information.`;
        submitStatus = status;
        break;
    }



    if (updatedOrder.user?.id) {
      try {
        await NotificationService.createNotification(
          updatedOrder.user.id, 
          notificationTitle as string,
          notificationMessage as string,
          'order_status',
          orderId,
          adminUserId,
          'client',
          submitStatus
        );
      } catch (error) {
        logger.error('Notification failed (but order updated):', error);
      }
    } 

    return updatedOrder;
  });
};

export const OrderService = {
  userAllOrders,
  userPublishedOrders,
  getAdminAllOrders,
  getAdminOrders,
  createOrder,
  runningOrders,
  getOrderById,
  getSpecificUserOrders,
  updateOrder,
  deleteOrder,
  getOrderStatistics,
  updateOrderStatus,
  userOrders,
  getRevenueStatistics,
  getUpcomingDeadlines,
  getPaymentRevenueStatistics
};
