import cron from 'node-cron';
import { logger } from '../../shared/logger';
import prisma from '../../shared/prisma';
import { NotificationService } from '../modules/notification/notification.service';
import { sendNotificationMail } from '../../helpers/mail';

let isCronRunning = false;

export const initOrderReminderCron = () => {
  if (process.env.NODE_APP_INSTANCE && process.env.NODE_APP_INSTANCE !== '0') {
    return;
  }

  cron.schedule('0 * * * *', async () => {
    if (isCronRunning) {
      return;
    }

    isCronRunning = true;

    try {
      const fortyEightHoursAgo = new Date(Date.now() - 72 * 60 * 60 * 1000);
      const fiveDaysAgo = new Date(Date.now() - 144 * 60 * 60 * 1000);

      const BATCH_SIZE = 100;
      let hasMore = true;
      const failedOrderIds: string[] = [];

      while (hasMore) {
        const pendingOrders = await prisma.order.findMany({
          where: {
            detailsSubmitted: 'not-yet',
            createdAt: {
              lte: fortyEightHoursAgo,
              gte: fiveDaysAgo,
            },
            id: {
              notIn: failedOrderIds,
            },
            notifications: {
              none: {
                type: '72h_reminder',
              },
            },
          
          },
          include: {
            user: {
              select: {
                name: true,
                notifyMail: true,
                notifySMS: true,
                email:true
              }
            },
          },
          take: BATCH_SIZE,
        });

        if (pendingOrders.length === 0) {
          hasMore = false;
          break;
        }

        for (const order of pendingOrders) {
          try {
            if (!order.userId) {
              console.warn(`Order ${order.orderId} has no userId. Skipping.`);
              failedOrderIds.push(order.id);
              continue;
            }

            if (order?.user?.notifyMail && order?.user?.email) {
              await sendNotificationMail(order?.user?.email, 'Action Required: Submit Article', `Your information submission for <span class='font-semibold'>#${order.orderId}</span> is overdue. Please submit it within 24 hours to avoid delays.`)
            }

            // if (order?.user?.notifySMS && order?.user?.phoneNumber) {
            //   await sendNotificationSMS(order?.user?.phoneNumber, 'Action Required: Submit Article', `Your information submission for <span class='font-semibold'>#${order.orderId}</span> is overdue. Please submit it within 24 hours to avoid delays.`)
            // }


            await NotificationService.createNotification(
              order.userId,
              'Action Required: Submit Article',
              `Your information submission for <span class='font-semibold'>#${order.orderId}</span> is overdue. Please submit it within 24 hours to avoid delays.`,
              '72h_reminder',
              order.id,
              order.userId,
              'client',
              'delay'
            );
            await NotificationService.createNotification(
              order.userId,
              'Order Submission Delayed',
              `<span class='font-semibold'>#${order.user?.name}</span> didn't submitted information for order <span class='font-semibold'>#${order.orderId}</span> yet! Follow-up required immediately.`,
              '72h_reminder',
              order.id,
              order.userId,
              'admin',
              'delay'
            );
          } catch (error) {
            console.error(`Failed to notify for order ${order.orderId}:`, error);
            failedOrderIds.push(order.id);
          }
        }
      }
    } catch (error) {
      logger.error('Critical error in order reminder cron job:', error);
    } finally {
      isCronRunning = false;
    }
  });
};